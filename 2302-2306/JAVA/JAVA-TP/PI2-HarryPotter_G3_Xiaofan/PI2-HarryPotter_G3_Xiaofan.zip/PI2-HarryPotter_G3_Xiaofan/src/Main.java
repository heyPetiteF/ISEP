import Home.Home;

public class Main {
    public static void main(String[] args) {
        new Home();
        //new Background.Background1();
        //new Background.Background2();
        //new Background.Background3();
        //new Level.preLevel();
        //new Level.Level77();
        //new Level.Level2();
        //new Level.Level3();
        //new END.WIN();
        //new END.loss();

    }
}